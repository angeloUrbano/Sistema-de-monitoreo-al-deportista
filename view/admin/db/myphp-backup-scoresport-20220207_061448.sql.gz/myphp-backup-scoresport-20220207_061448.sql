CREATE DATABASE IF NOT EXISTS `scoresport`;

USE `scoresport`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `bateo`;

CREATE TABLE `bateo` (
  `idbateo` int(11) NOT NULL AUTO_INCREMENT,
  `nrobateo` varchar(150) NOT NULL,
  `cod` varchar(150) NOT NULL,
  `realizadopor` varchar(150) NOT NULL,
  `fecha` varchar(150) NOT NULL,
  `promedio` varchar(150) NOT NULL,
  PRIMARY KEY (`idbateo`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

INSERT INTO `bateo` VALUES (14,2,1234354353,26115037,"07-02-2022","Hit|Out"),
(15,2,1234567,26115037,"07-02-2022","1|0"),
(16,10,27654892,26115037,"","");


DROP TABLE IF EXISTS `condicion`;

CREATE TABLE `condicion` (
  `idcondi` int(11) NOT NULL AUTO_INCREMENT,
  `velocidad` varchar(150) NOT NULL,
  `peso` varchar(150) NOT NULL,
  `estatura` varchar(150) NOT NULL,
  `cod` varchar(150) NOT NULL,
  `realizadopor` varchar(150) NOT NULL,
  `fecha` varchar(150) NOT NULL,
  PRIMARY KEY (`idcondi`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `condicion` VALUES (8,7,22,"1.5",27654892,26115037,"07-02-2022"),
(9,20,20,"1.2",27654892,26115037,"07-02-2022"),
(10,9,20,15,26115037,26115037,"07-02-2022");


DROP TABLE IF EXISTS `dataprimaryathletes`;

CREATE TABLE `dataprimaryathletes` (
  `idatletas` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `lastname` varchar(150) NOT NULL,
  `age` varchar(150) NOT NULL,
  `dateofbirth` varchar(150) NOT NULL,
  `code` varchar(150) NOT NULL,
  `ci` varchar(150) NOT NULL,
  PRIMARY KEY (`idatletas`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `dataprimaryathletes` VALUES (1,"luis","navas",25,"1996-11-25",26115037,26115037),
(2,"Hodward","Yepez",24,"1997-03-05",27654892,27654892),
(3,"david","quitero",15,"1995-11-25",1234567,1234567),
(4,"luciano","navas",25,"2022-02-21",1234354353,1234354353);


DROP TABLE IF EXISTS `pitcheo`;

CREATE TABLE `pitcheo` (
  `idpitcheo` int(11) NOT NULL AUTO_INCREMENT,
  `tipolanza` varchar(150) NOT NULL,
  `nrolanza` varchar(150) NOT NULL,
  `cod` varchar(150) NOT NULL,
  `velocidad` varchar(150) NOT NULL,
  `status` varchar(150) NOT NULL,
  `realizadopor` varchar(150) NOT NULL,
  `fecha` varchar(150) NOT NULL,
  PRIMARY KEY (`idpitcheo`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4;

INSERT INTO `pitcheo` VALUES (54,"Recta",2,26115037,"","",26115037,"");


DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `clave` varchar(255) NOT NULL,
  `cargo` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `usuarios` VALUES (1,"Eduardo Montiel","dezain","202cb962ac59075b964b07152d234b70",1);


SET foreign_key_checks = 1;
